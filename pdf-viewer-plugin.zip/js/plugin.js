
(function () {
  'use strict';

  kintone.events.on('app.record.detail.show', function (event) {
    const anchor = document.querySelector('[data-field-code="pdf_link"] a');

    if (anchor && anchor.href.endsWith('.pdf')) {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        showPDFModal(anchor.href);
      });
    }

    return event;
  });

  function showPDFModal(pdfUrl) {
    const existingModal = document.getElementById('kintone-pdf-modal');
    if (existingModal) existingModal.remove();

    const modal = document.createElement('div');
    modal.id = 'kintone-pdf-modal';
    modal.innerHTML = `
      <div class="modal-content">
        <button id="modal-close">×</button>
        <iframe src="https://mozilla.github.io/pdf.js/web/viewer.html?file=${encodeURIComponent(pdfUrl)}"
                width="100%" height="600px" frameborder="0"></iframe>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('#modal-close').addEventListener('click', () => modal.remove());
  }
})();
